import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    
    def props = message.getProperties()
    
    String firstName = props.get("P_firstName") ?: ""
    String lastName  = props.get("P_lastName")  ?: ""
    String empId     = props.get("P_employeeId") ?: ""
    
    // Correlativo simple con timestamp
    String correlativo = String.valueOf(System.currentTimeMillis()).takeRight(5)
    
    String idoc = """<?xml version="1.0" encoding="UTF-8"?>
<DEBMAS06>
  <IDOC BEGIN="1">
    <EDI_DC40 SEGMENT="1">
      <MESTYP>DEBMAS</MESTYP>
      <IDOCTYP>DEBMAS06</IDOCTYP>
      <SNDPOR>PORT_CPI</SNDPOR>
      <SNDPRT>US</SNDPRT>
      <SNDPRN>CPI_DEMO</SNDPRN>
      <DOCNUM>11000000000${correlativo}</DOCNUM>
      <RCVPRN>EC5CLNT400</RCVPRN>
      <RCVPRT>LS</RCVPRT>
    </EDI_DC40>
    <E1KNA1M SEGMENT="1">
      <MSGFN>009</MSGFN>
      <NAME1>Agustina Mendoza, ${firstName} ${lastName}, ${empId}</NAME1>
      <ORT01>BUENOS AIRES</ORT01>
      <PSTLZ>C1043AAX</PSTLZ>
      <LAND1>AR</LAND1>
      <SPRAS>S</SPRAS>
      <ORT02>RECOLETA</ORT02>
    </E1KNA1M>
  </IDOC>
</DEBMAS06>"""

    message.setBody(idoc)
    message.setHeader("Content-Type", "text/xml")
    return message
}
